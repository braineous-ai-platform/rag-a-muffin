package ai.braineous.rag.prompt.models.cgo.graph;

public enum ProposalStatus {
    PENDING,
    APPROVED,
    REJECTED,
    PARTIALLY_APPROVED
}
