package ai.braineous.rag.prompt.cgo.api;

public interface LLMBridge {

    public GraphView submit(LLMContext llmContext);
}
