package ai.braineous.rag.prompt.models.cgo.graph;

public enum ProposalSource {
    RULE,
    LLM,
    USER,
    SYSTEM
}