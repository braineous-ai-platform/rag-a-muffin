package ai.braineous.rag.prompt.observe;

public interface Summarizer {
}
