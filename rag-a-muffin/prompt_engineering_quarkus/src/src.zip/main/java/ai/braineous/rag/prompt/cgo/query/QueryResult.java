package ai.braineous.rag.prompt.cgo.query;

public class QueryResult {
}
