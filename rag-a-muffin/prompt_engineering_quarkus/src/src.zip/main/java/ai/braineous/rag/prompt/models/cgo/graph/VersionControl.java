package ai.braineous.rag.prompt.models.cgo.graph;

public class VersionControl {
}
