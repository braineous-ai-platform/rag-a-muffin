package ai.braineous.rag.prompt.services;

import jakarta.enterprise.context.RequestScoped;

@RequestScoped
public class PromptService {

}
