package ai.braineous.fno.controllers;

import ai.braineous.rag.prompt.observe.Console;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.junit.jupiter.api.Test;

public class PromptControllerTests {

    @Test
    void fnoQuery_returns200_andStableResponseShape() {

        Console.log("test", "fnoQuery_returns200_andStableResponseShape");

        JsonObject payload = new JsonObject();

        JsonObject meta = new JsonObject();
        meta.addProperty("traceId", "t-001");
        meta.addProperty("source", "PromptControllerE2E");
        payload.add("meta", meta);

        JsonObject task = new JsonObject();
        task.addProperty("factId", "FACT-123");
        payload.add("task", task);

        JsonObject graphContext = new JsonObject();
        graphContext.add("nodes", new com.google.gson.JsonArray());
        graphContext.add("edges", new com.google.gson.JsonArray());
        payload.add("graphContext", graphContext);

        Console.log("requestBody", payload);

        String responseBody =
                io.restassured.RestAssured
                        .given()
                        .contentType("application/json")
                        .body(payload.toString())
                        .when()
                        .post("/fno/query")
                        .then()
                        .statusCode(200)
                        .extract()
                        .asString();

        Console.log("responseBody", responseBody);

        JsonObject out = JsonParser.parseString(responseBody).getAsJsonObject();

        org.junit.jupiter.api.Assertions.assertTrue(out.has("rawResponse"));
        org.junit.jupiter.api.Assertions.assertTrue(out.has("promptValidation"));
        org.junit.jupiter.api.Assertions.assertTrue(out.has("llmResponseValidation"));
        org.junit.jupiter.api.Assertions.assertTrue(out.has("domainValidation"));
    }


}
